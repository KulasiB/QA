package SignUP;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
public class JsonReader {


    static JSONParser parser = new JSONParser();
    public static String ReadJSONFile (String nameParameter, String filePath) throws FileNotFoundException, IOException, ParseException
    {
        Object obj = parser.parse(new FileReader(filePath));

        JSONObject jsonObject = (JSONObject) obj;
        String value = (String) jsonObject.get(nameParameter);
        return value;
    }

    public JSONArray ReadJSONFile_Array ( String filePath) throws FileNotFoundException, IOException, ParseException
    {
        JSONParser jsonParser = new JSONParser();
        JSONArray jsonarray =  (JSONArray) jsonParser.parse(new FileReader(filePath));
        return jsonarray;
    }

    @SuppressWarnings("unchecked")
    public static void UpdateJSONFile(String nameParameter, String filePath, String newValue) throws IOException, ParseException {
        Object obj = parser.parse(new FileReader(filePath));
        JSONObject jsonObject = (JSONObject) obj;
        jsonObject.put(nameParameter, newValue);
        FileWriter fileWriter = new FileWriter(filePath);
        fileWriter.write(jsonObject.toJSONString());
        fileWriter.close();
    }


}













