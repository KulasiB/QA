package SignUP;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class UltimateQASignUP {

    public static WebDriver driver;

    UltimateQASignUP signUP;
    By LoginAutomation = By.xpath("//a[@href=\"http://courses.ultimateqa.com/users/sign_in\"]");
    By CreateANewAccount = By.xpath("//a [@href=\"/users/sign_up\"]");
    By EnterFirstName = By.xpath("(//input[@type=\"text\"])[1]");

    By EnterLastName = By.xpath("(//input[@type=\"text\"])[2]");
    By EnterEmail = By.xpath("(//input[@type=\"text\"])[3]");

    By EnterPassword = By.xpath("//input[@type=\"password\"]");
    By Agreement = By.xpath("//label[@class=\"form__label--checkbox\"]");

    By SignUP_BUTTON = By.xpath("//button[@type=\"submit\"]");

    By SignIn_Button = By.xpath("//button[@type=\"submit\"]");
    By Account = By.xpath("//button[@class=\"dropdown__toggle-button\"]");

    By MyAccount = By.xpath("//a[@href=\"/account\"]");

    By ProfilePhoto = By.xpath("//span[@class=\"button-upload\"]");

    public UltimateQASignUP(WebDriver getdriver) {

    }
    //LoginAutomation
    public void LoginAutomation(){driver.findElement(LoginAutomation).click();}
    //Create A New Account
    public void CreateANewAccount(){driver.findElement(CreateANewAccount).click();}
    //First Name
    public void EnterFirstName(String name) {driver.findElement(EnterFirstName).sendKeys(name);}
    //Second Name
    public void EnterLastName(String name) {driver.findElement(EnterLastName).sendKeys(name);}
    //Email
    public void EnterEmail(String email) {List<WebElement> emailElements = driver.findElements(EnterEmail);
        if (!emailElements.isEmpty()) {
            emailElements.get(0).sendKeys(email);
        } else {
            System.out.println("No email element found");
        }
    }
    //Password
    public void EnterPassword(String password) {
        List<WebElement> passwordElements = driver.findElements(EnterPassword);
        if (!passwordElements.isEmpty()) {
            passwordElements.get(0).sendKeys(password);
        } else {

            System.out.println("No password element found");
        }
    }
    //I have read and agree to the Terms of Use and Customer Privacy Policy.
    public void Agreement() {
        WebElement agreementCheckbox = driver.findElement(Agreement);

        // Check if the checkbox is not already selected
        if (!agreementCheckbox.isSelected()) {
            agreementCheckbox.click(); // Select the checkbox
        } else {
            // Optionally, you can add code to handle the case when the checkbox is already selected
            System.out.println("Checkbox is already selected");
        }
    }


    //Sign Up
    public void SignUP_BUTTON(){driver.findElement(SignUP_BUTTON).click();}

    //Sign In
    public void SignIn_Button(){driver.findElement(SignIn_Button).click();}

    //Account

    public void Account(){driver.findElement(Account).click();}
    //My Account
    public void MyAccount(){driver.findElement(MyAccount).click();}
    //Profile Photo
    public void ProfilePhoto(String link){driver.findElement(ProfilePhoto).sendKeys(link);}





}


