import SignUP.UltimateQASignUP;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.Paths;

public class SignInTest {
    private WebDriver driver;

    private UltimateQASignUP signIn;
    private static JSONObject userData;

    static {
        JSONParser parser = new JSONParser();
        try {
            Object obj = parser.parse(new FileReader("src/main/resources/UltimateQA.json"));
            userData = (JSONObject) obj;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @BeforeMethod
    public void setup() {
        // Specify the path to your downloaded ChromeDriver executable
        //System.setProperty("webdriver.chrome.driver", "C:\\WebDriver\\chromedriver.exe");
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        signIn = new UltimateQASignUP (driver);
        WebDriverManager.chromedriver().setup();
        driver.manage().window().maximize();
        driver.get("https://ultimateqa.com/automation");
    }
    @Test(priority = 1)
    public void loginTest() {
        String jsonContent = null;
        try {
            jsonContent = new String(Files.readAllBytes(Paths.get("src/main/resources/UltimateQA.json")));
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Parse JSON content
        assert jsonContent != null;
        JSONObject jsonData = new JSONObject(jsonContent);
        signIn.EnterEmail(jsonData.getString("email"));
        signIn.EnterPassword(jsonData.getString("password"));
        signIn.SignIn_Button();
        signIn.Account();
        signIn.MyAccount();
        signIn.ProfilePhoto(jsonData.getString("pathProfile"));
    }
    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();


        }
    }}